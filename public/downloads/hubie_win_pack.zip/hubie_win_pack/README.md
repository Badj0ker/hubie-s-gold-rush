# Hubie's Gold Rush - Win Pack

- panels/ : WIN, BIG WIN, SUPERB WIN, MAX WIN transparent PNGs (1024x768) + panels.json (number box coordinates, tier thresholds as win/bet multiples)
- font/ : Chunky 3D Gold bitmap font sheet (1024x1024, glyphs 0-9 . x) + hubie_gold_font.json (glyph x/y/w/h in sheet pixels)
- preview.html : open directly in a browser (no internet needed). 4 single panels + Full Escalation with roll-up, pulse/bounce, coin rain, confetti, sounds, click to skip.

Glyph kerning: overlap neighbouring glyphs by ~16px at 243px glyph height. Align glyph bottoms on one baseline.
