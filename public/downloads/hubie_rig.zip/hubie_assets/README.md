# Hubie Rig (PixiJS + GSAP, no Spine)
Open demo/index.html in a browser (internet needed for the PixiJS/GSAP CDN).
- master/ – original Hubie (used as the Big Win image)
- layers/ – transparent reference cut-outs from the parts sheet (swap in final art, keep file names)
- config/pivots.json – size, pivot (normalized anchor), rig-space position, parent, draw order
- animation_specs/ – idle, spin, win, big_win, lose
