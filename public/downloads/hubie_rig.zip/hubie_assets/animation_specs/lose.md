# Lose
- Head drops: head rotation 0 → 8°, y +12px, 0.35s, power2.out.
- Hold 0.4s, then return to Idle over 0.5s, sine.inOut.
