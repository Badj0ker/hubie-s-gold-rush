# Spin (while reels spin)
- Root rocks forward/back: rotation 0 → 3° → -2° → 0, 0.6s, power1.inOut, repeat while spinning.
- Gold coin flash near hand_right: alpha 0 → 1 → 0, scale 0.6 → 1.1, 0.35s.
- Return to Idle when the spin result arrives.
