# Big Win
- Swap rig for the master image (master/hubie_original.png) — the official full pose.
- Jumps: y 0 → -80 → 0, 0.5s, power2.out / bounce.out, 4 times; squash scaleY 0.92 on landing.
- Confetti + gold coins burst from top, 3s; golden glow pulse behind Hubie.
- Fade back to layered rig and Idle.
