# Win
- Bigger bounce: y 0 → -40 → 0, 0.45s, back.out(2), 2 repeats.
- Thumbs-up pose: arm_left_upper rotation -35°, hand_left (thumbs-up layer) scale pop 1 → 1.15 → 1.
- Hold 0.8s, then blend back to Idle over 0.4s.
