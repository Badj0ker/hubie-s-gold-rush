# Idle (loop)
- Whole rig floats: y ±6px, 2.4s, sine.inOut, yoyo.
- Breathing: torso + jacket_front scaleY 1 → 1.02, 2.4s, synced with float.
- Slow lean: root rotation ±1.5°, 4s, sine.inOut.
- Head counter-tilt ±1°, hat follows head (child).
